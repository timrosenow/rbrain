"""
rbrain.

MRI analysis software for rodent brains.
"""
__version__ = '0.1.0'
__author__ = 'Tim Rosenow'
__credits__ = 'National Imaging Facility'

import rbrain.segmenter
