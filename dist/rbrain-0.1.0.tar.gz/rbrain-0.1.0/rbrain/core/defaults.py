# TODO: Update default config file with some kind of install dir setting
# For now: current working directory
DEF_CONF_FILE = "rbrain/rbrain.cfg"
